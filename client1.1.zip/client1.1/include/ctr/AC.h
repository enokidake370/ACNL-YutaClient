#ifndef AC_H
#define AC_H

Result ACU_GetWifiStatus(Handle servhandle, u32 *out);
Result ACU_WaitInternetConnection();

#endif

