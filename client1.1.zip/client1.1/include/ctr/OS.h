#ifndef OS_H
#define OS_H

u32 OS_ConvertVaddr2Physaddr(u32 vaddr);

#endif

