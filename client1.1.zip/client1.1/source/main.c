
#include "global.h"
#include "ov.h"

FS_archive sdmcArchive = { 0x9, (FS_path){ PATH_EMPTY, 1, (u8*)"" } };
Handle fsUserHandle = 0;

#define CALLBACK_OVERLAY (101)



#define TICKS_PER_MSEC (268123.480)

#define WRITEU8(addr, data) *(vu8*)(addr) = data
#define WRITEU16(addr, data) *(vu16*)(addr) = data
#define WRITEU32(addr, data) *(vu32*)(addr) = data

u32 threadStack[0x1000];
Handle fsUserHandle;
FS_archive sdmcArchive;


#define IO_BASE_PAD		1
#define IO_BASE_LCD		2
#define IO_BASE_PDC		3
#define IO_BASE_GSPHEAP		4


int frameCount[2];
u64 lastUpdatedTick[2];
int fps[2];


void drawA(int calculateFps, int isBottom, u32 addr, u32 stride, u32 format, u32 colOffset) {
	u32 height = isBottom ? 320 : 400;
	char buf[30];
	if (calculateFps) {
		frameCount[isBottom] ++;
		if (frameCount[isBottom] >= 64) {
			frameCount[isBottom] = 0;
			u64 tickNow = svc_getSystemTick();
			u64 diff = tickNow - lastUpdatedTick[isBottom] ;
			lastUpdatedTick[isBottom] = tickNow;
			fps[isBottom] = 64.0 / ((double) (diff) / TICKS_PER_MSEC / 1000.0) * 10.0;
		}
	}

	xsprintf(buf, "Yuta Client by Yuta");
	ovDrawString(addr, stride, format, height, 10, colOffset + 4, 255, 255, 255, buf);
}

void drawB(int calculateFps, int isBottom, u32 addr, u32 stride, u32 format, u32 colOffset) {
	u32 height = isBottom ? 320 : 400;
	char ver[40];
	if (calculateFps) {
		frameCount[isBottom] ++;
		if (frameCount[isBottom] >= 64) {
			frameCount[isBottom] = 0;
			u64 tickNow = svc_getSystemTick();
			u64 diff = tickNow - lastUpdatedTick[isBottom] ;
			lastUpdatedTick[isBottom] = tickNow;
			fps[isBottom] = 64.0 / ((double) (diff) / TICKS_PER_MSEC / 1000.0) * 10.0;
		}
	}

	xsprintf(ver, "v1.1a");
	ovDrawString(addr, stride, format, height, 20, colOffset + 4, 255, 255, 255, ver);
}

void drawC(int calculateFps, int isBottom, u32 addr, u32 stride, u32 format, u32 colOffset) {
	u32 height = isBottom ? 320 : 400;
	char menu[40];
	if (calculateFps) {
		frameCount[isBottom] ++;
		if (frameCount[isBottom] >= 64) {
			frameCount[isBottom] = 0;
			u64 tickNow = svc_getSystemTick();
			u64 diff = tickNow - lastUpdatedTick[isBottom] ;
			lastUpdatedTick[isBottom] = tickNow;
			fps[isBottom] = 64.0 / ((double) (diff) / TICKS_PER_MSEC / 1000.0) * 10.0;
		}
	}

	xsprintf(menu, "#--CheatMenu--#");
	ovDrawString(addr, stride, format, height, 40, colOffset + 4, 255, 255, 255, menu);
}

void drawD(int calculateFps, int isBottom, u32 addr, u32 stride, u32 format, u32 colOffset) {
	u32 height = isBottom ? 320 : 400;
	char menu[40];
	if (calculateFps) {
		frameCount[isBottom] ++;
		if (frameCount[isBottom] >= 64) {
			frameCount[isBottom] = 0;
			u64 tickNow = svc_getSystemTick();
			u64 diff = tickNow - lastUpdatedTick[isBottom] ;
			lastUpdatedTick[isBottom] = tickNow;
			fps[isBottom] = 64.0 / ((double) (diff) / TICKS_PER_MSEC / 1000.0) * 10.0;
		}
	}

	xsprintf(menu, "NTRMenu is X+Y");
	ovDrawString(addr, stride, format, height, 50, colOffset + 4, 255, 255, 255, menu);
}

void drawE(int calculateFps, int isBottom, u32 addr, u32 stride, u32 format, u32 colOffset) {
	u32 height = isBottom ? 320 : 400;
	char bufa[30];
	if (calculateFps) {
		frameCount[isBottom] ++;
		if (frameCount[isBottom] >= 64) {
			frameCount[isBottom] = 0;
			u64 tickNow = svc_getSystemTick();
			u64 diff = tickNow - lastUpdatedTick[isBottom] ;
			lastUpdatedTick[isBottom] = tickNow;
			fps[isBottom] = 64.0 / ((double) (diff) / TICKS_PER_MSEC / 1000.0) * 10.0;
		}
	}

	xsprintf(bufa, "fps: %d.%d", fps[isBottom] / 10, fps[isBottom] % 10);
	ovDrawString(addr, stride, format, height, 70, colOffset + 4, 255, 255, 255, bufa);
}

void drawF(int calculateFps, int isBottom, u32 addr, u32 stride, u32 format, u32 colOffset) {
	u32 height = isBottom ? 320 : 400;
	char menu2[30];
	if (calculateFps) {
		frameCount[isBottom] ++;
		if (frameCount[isBottom] >= 64) {
			frameCount[isBottom] = 0;
			u64 tickNow = svc_getSystemTick();
			u64 diff = tickNow - lastUpdatedTick[isBottom] ;
			lastUpdatedTick[isBottom] = tickNow;
			fps[isBottom] = 64.0 / ((double) (diff) / TICKS_PER_MSEC / 1000.0) * 10.0;
		}
	}

	xsprintf(menu2, "#-------------#");
	ovDrawString(addr, stride, format, height, 80, colOffset + 4, 255, 255, 255, menu2);
}

void drawG(int calculateFps, int isBottom, u32 addr, u32 stride, u32 format, u32 colOffset) {
	u32 height = isBottom ? 320 : 400;
	char money[30];
	if (calculateFps) {
		frameCount[isBottom] ++;
		if (frameCount[isBottom] >= 64) {
			frameCount[isBottom] = 0;
			u64 tickNow = svc_getSystemTick();
			u64 diff = tickNow - lastUpdatedTick[isBottom] ;
			lastUpdatedTick[isBottom] = tickNow;
			fps[isBottom] = 64.0 / ((double) (diff) / TICKS_PER_MSEC / 1000.0) * 10.0;
		}
	}

	xsprintf(money, "Infinite Money");
	ovDrawString(addr, stride, format, height, 60, colOffset + 4, 255, 255, 255, money);
}


/*
Overlay Callback.
isBottom: 1 for bottom screen, 0 for top screen.
addr: writable cached framebuffer virtual address.
addrB: right-eye framebuffer for top screen, undefined for bottom screen.
stride: framebuffer stride(pitch) in bytes, at least 240*bytes_per_pixel.
format: framebuffer format, see https://www.3dbrew.org/wiki/GPU/External_Registers for details.

NTR will invalidate data cache of the framebuffer before calling overlay callbacks. NTR will flush data cache after the callbacks were called and at least one overlay callback returns zero.

return 0 when the framebuffer was modified. return 1 when nothing in the framebuffer was modified.
*/

u32 overlayCallback(u32 isBottom, u32 addr, u32 addrB, u32 stride, u32 format) {
	drawA(1, isBottom, addr, stride, format, 14);
	drawB(1, isBottom, addr, stride, format, 14);
	drawC(1, isBottom, addr, stride, format, 14);
	drawD(1, isBottom, addr, stride, format, 14);
	drawE(1, isBottom, addr, stride, format, 14);
	drawF(1, isBottom, addr, stride, format, 14);
	drawG(1, isBottom, addr, stride, format, 14);

	//Infinite Money Code
	WRITEU32(0x002C01C8, 0xE3A08000);
	
	// In 2D mode, top screen's addrB might be invalid or equal to addr, do not draw on addrB in either situations
	return 0;
}

int main() {
	u32 retv;
	
	initSharedFunc();
	plgRegisterCallback(CALLBACK_OVERLAY, (void*) overlayCallback, 0);
	return 0;
}

